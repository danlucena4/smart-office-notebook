ENTREGA — Smart Office (Notebook + CSV)

Conteúdo:
- analise_smart_office.ipynb  → Notebook auto-contido (gera smart_office_data.csv se não existir)
- project_progress.csv        → Progresso do projeto
- (opcional) smart_office_data.csv será gerado na 1ª execução do notebook

Como o professor pode executar:
1) Abrir o .ipynb no Google Colab (Upload) OU no VS Code (extensões Python + Jupyter) OU Jupyter local.
2) Rodar "Run all" / "Executar tudo".
3) O notebook cria smart_office_data.csv automaticamente, caso não esteja na pasta.

Observações:
- O notebook inclui gráficos (Planejado vs Real, Burndown, série temporal, Antes vs Depois).
- Há seções de Data Storytelling e recomendações na fase final.